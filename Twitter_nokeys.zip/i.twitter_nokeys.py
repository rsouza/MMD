''' 
Mestrado em Modelagem Matematica da Informacao
Disciplina de Modelagem e Mineracao de Dados
Professor: Renato Rocha Souza
Topico: Twitter, NLTK, Visualizacao de Redes e PLN
'''

from __future__ import division
import twitter #Usando API http://code.google.com/p/python-twitter/
import nltk
import re
import networkx as nx
import sys
import os
import json
import webbrowser
import codecs
import xmlrpclib
import ubigraph
from itertools import cycle
import numpy as np
from matplotlib.pyplot import plot, show, title, legend, figure

#Especificando o caminho para o arquivo
datapath = "/home/rsouza/Dropbox/Renato/Python/MMD/"
dotfile = "grafo_retweet.dot"
protofile = "grafo_retweet.html"
template_proto = 'template_protoviz.html'
pathdotfile = (datapath+dotfile)
pathprotofile = (datapath+protofile)
pathtemplate = (datapath+template_proto)
ubiServer = "http://127.0.0.1:20738/RPC2"

# Chaves de autenticacao - Twitter API
ck = 'preencher o seu'
cs = 'preencher o seu'
atk = 'preencher o seu'
ats = 'preencher o seu'

def buscaportermo(termo):
    '''Criacao de base de tweets'''
    # Uma busca por um termo em tweets com mais resultados (5 paginas x 100 tweets)
    search_results = []
    tweets = []
    tweets_txt = []
    tweets_words = []
    names = []
    for page in range(1,6):
        search_results.append(api.GetSearch(term=termo, per_page=100, page=page))
    for i in range(len(search_results)):
        for j in range(len(search_results[i])):
            tweets.append(search_results[i][j])
    tweets_txt += [str(tweet.text).split(' ') for tweet in tweets]
    for i in range(len(tweets)): tweets_words += [word.lower().strip(':@&$!?') for word in tweets_txt[i]]
    for i in range(len(tweets)): names += [word.strip(':@&$!?') for word in tweets_txt[i] if word.istitle() and len(word) > 2]
    #salvando os tweets em um arquivo
    #out = file('dump.txt','w')
    #for tweet in tweets_txt: out.write('\n%s' % tweet) #Escreve os tweets, um por linha
    return tweets, tweets_txt, tweets_words, names

'''Bloco de criacao de grafos'''
def get_rt_origins(tweet):
    # Regex adapted from 
    # http://stackoverflow.com/questions/655903/python-regular-expression-for-retweets
    rt_patterns = re.compile(r"(RT|via)((?:\b\W*@\w+)+)", re.IGNORECASE)
    rt_origins = []
    try:
        rt_origins += [mention.strip() for mention in rt_patterns.findall(tweet)[0][1].split()]
    except IndexError, e:
        pass
    return [rto.strip("@") for rto in rt_origins]

def cria_grafo_retweets(tweets):
    g = nx.DiGraph()
    for tweet in tweets:
        rt_origins = get_rt_origins(tweet.text)
        if not rt_origins:
            continue
        for rt_origin in rt_origins:
            g.add_edge(rt_origin, tweet.user.screen_name, {'tweet_id': tweet.id})
    return g

def salva_arquivo_dot(g):
    try:
        nx.drawing.write_dot(g, pathdotfile)
        print >> sys.stderr, 'Grafo exportado para arquivo: %s' %pathdotfile
    except (ImportError, UnicodeEncodeError): 
        # Este bloco serve para usuarios de windows, que certamente terao problemas
        # com o metodo nx.drawing.write_dot. Tambem serve para os casos em que temos
        # problemas com o unicode
        dot = ['"%s" -> "%s" [tweet_id=%s]' % (n1, n2, g[n1][n2]['tweet_id'])
               for (n1, n2) in g.edges()]
        f = codecs.open(pathdotfile, 'w', encoding='utf-8')
        f.write('''strict digraph {%s}''' % (';\n'.join(dot), ))
        f.close()
        print >> sys.stderr, 'Grafo exportado para arquivo: %s' % f.name
        return f.name

# Outra opcao de visualizacao e o protovis, que gera um arquivo html que
# pode ser exibido em um navegador. Os arquivos template_protoviz.html e
# protovis-r3.2.js devem estar na pasta definida no datapath 
def salva_arquivo_protovis(g):
    nodes = g.nodes()
    indexed_nodes = {}
    idx = 0
    for n in nodes:
        indexed_nodes.update([(n, idx,)])
        idx += 1
    links = []
    for n1, n2 in g.edges():
        links.append({'source': indexed_nodes[n2],'target': indexed_nodes[n1]})
    json_data = json.dumps({"nodes" : [{"nodeName" : n} for n in nodes], "links" : links}, indent=4)
    html = open(pathtemplate).read() % (json_data,)
    f = open(pathprotofile, 'w')
    f.write(html)
    f.close()
    print >> sys.stderr, 'Grafo exportado para arquivo: %s' %f.name
    return f.name

def comandos_para_criacao_dos_grafos(tweets):
    g_rt = cria_grafo_retweets(tweets)
    print g_rt.number_of_nodes()
    print g_rt.number_of_edges()
    print nx.degree(g_rt)
    dic = nx.degree(g_rt)
    print sorted(dic.values())
    plot(sorted(dic.values()))
    salva_arquivo_dot(g_rt)
    # a partir do arquivo dot, gerar arquivo png digitando no prompt (unix): 
    #'circo -Tpng -Ografo_retweet grafo_retweet.dot'
    salva_arquivo_protovis(g_rt)
    mostra_grafo_ubigraph(g_rt)

def mostra_grafo_ubigraph(graph, vstyles=[],estyles=[]):
    """
    Visualizacao dinamica usando ubigraph
    Servidor Ubigraph deve estar rodando na URL indicada
    graph.edges is a list of tuples: (n1,n2,w)
    """
    U = ubigraph.Ubigraph(URL=ubiServer)
    U.clear()
    nodes = {}
    edges = set([])
    #maxw = float(max(np.array([i[2] for i in graph.edges()]))) #largest weight
    if not vstyles:
        vstyles = cycle([U.newVertexStyle(id=1,shape="sphere", color="#ff0000")])
    else:
        vstyles = cycle(vstyles)
    rt_style = U.newVertexStyle(id=2,shape="sphere", color="#00ff00")
    for e in graph.edges():
        if e[0] not in nodes:
            n1 = U.newVertex(style=vstyles.next(), label=str(e[0]))#.decode('latin-1'))
            nodes[e[0]] = n1
        else:
            n1 = nodes[e[0]]
        if e[1] not in nodes:
            n2 = U.newVertex(style=rt_style, label=str(e[1]))
            nodes[e[1]] = n2
        else:
            n2 = nodes[e[1]]
        #es = e[2]/maxw
        if (n1,n2) not in edges:
            #U.newEdge(n1,n2,spline=True,strength=es, width=2.0, showstrain=True)
            U.newEdge(n1,n2,spline=True, width=2.0, showstrain=True)
            edges.add((n1,n2))
            edges.add((n2,n1))

'''Bloco de analises lexicais'''

lista_positiva = ['Abundant','Accomplished','Achieving','Active','Admirable','Adorable',
                  'Adventurous','Admired','Affluent','Agreeable','Alert','Aligned','Alive',
                  'Amazing','Appealing','Appreciate','Artistic','Astounding','Astute',
                  'Attentive','Attractive','Auspicious','Authentic','Awake','Aware','Awesome',
                  'Beaming','Beautiful','Better','Best','Blessed','Bliss','Bold','Bright','Brilliant',
                  'Brisk','Buoyant','Calm','Capable','Centered','Certain','Charming',
                  'Cheerful','Clear','Clever','Competent','Complete','Confident','Connected',
                  'Conscious','Considerate','Convenient','Courageous','Creative','Daring',
                  'Dazzling','Delicious','Delightful','Desirable','Determined','Diligent',
                  'Discerning','Discover','Dynamic','Eager','Easy','Efficient','Effortless',
                  'Elegant','Eloquent','Energetic','Endless','Enhancing','Engaging','Enormous'
                  ,'Enterprising','Enthusiastic','Enticing','Excellent','Exceptional','Exciting'
                  ,'Experienced','Exquisite','Fabulous','Fair','Far-Sighted','Fascinating',
                  'Fine','Flattering','Flourishing','Fortunate','Free','Friendly','Fulfilled',
                  'Fun','Generous','Genuine','Gifted','Glorious','Glowing','Good','Good-Looking',
                  'Gorgeous','Graceful','Gracious','Grand','Great','Handsome','Happy','Hardy',
                  'Harmonious','Healed','Healthy','Helpful','Honest','Humorous','Ideal',
                  'Imaginative','Impressive','Industrious','Ingenious','Innovative','Inspired',
                  'Intelligent','Interested','Interesting','Intuitive','Inventive','Invincible',
                  'Inviting','Irresistible','Joyous','Judicious','Keen','Kind','Knowing','Leader',
                  'Limitless','Lively','Loving','Lucky','Luminous','Magical','Magnificent',
                  'Marvellous','Masterful','Mighty','Miraculous','Motivated','Natural','Neat',
                  'Nice','Nurturing','Noble','Optimistic','Outstanding','Passionate','Peaceful',
                  'Perfect','Persevering','Persistent','Playful','Pleasing','Plentiful','Positive',
                  'Powerful','Precious','Prepared','Productive','Profound','Prompt','Prosperous',
                  'Proud','Qualified','Quick','Radiant','Reasonable','Refined','Refreshing',
                  'Relaxing','Reliable','Remarkable','Resolute','Resourceful','Respected',
                  'Rewarding','Robust','Safe','Satisfied','Secure','Seductive','Self-Reliant',
                  'Sensational','Sensible','Sensitive','Serene','Sharing','Skilful','Smart',
                  'Smashing','Smooth','Sparkling','Spiritual','Splendid','Strong','Stunning',
                  'Successful','Superb','Swift','Talented','Tenacious','Terrific','Thankful',
                  'Thrilling','Thriving','Timely','Trusting','Truthful','Ultimate','Unique',
                  'Valiant','Valuable','Versatile','Vibrant','Victorious','Vigorous','Vivacious',
                  'Vivid','Warm','Wealthy','Well','Whole','Wise','Wonderful','Worthy','Young',
                  'Youthful','Zeal','Zest']

lista_negativa = ['abandoned','abused','accused','addicted','afraid','aggravated',
                  'aggressive','alone','angry','anguish','annoyed','anxious','apprehensive',
                  'argumentative','artificial','ashamed','assaulted','at a loss','at risk',
                  'atrocious','attacked','avoided','awful','awkward','bad','badgered','baffled',
                  'banned','barren','beat','beaten down','belittled','berated','betrayed',
                  'bitched at','bitter','bizzare','blacklisted','blackmailed','blamed','bleak',
                  'blown away','blur','bored','boring','bossed-around','bothered','bothersome',
                  'bounded','boxed-in','broken','bruised','brushed-off','bugged','bullied',
                  'bummed','bummed out','burdened','burdensome','burned','burned-out',
                  'caged in','careless','chaotic','chased','cheated','cheated on','chicken',
                  'claustrophobic','clingy','closed','clueless','clumsy','coaxed',
                  'codependent','coerced','cold','cold-hearted','combative','commanded',
                  'compared','competitive','compulsive','conceited','concerned',
                  'condescended to','confined','conflicted','confronted','confused',
                  'conned','consumed','contemplative','contempt','contentious','controlled',
                  'convicted','cornered','corralled','cowardly','crabby','cramped','cranky',
                  'crap','crappy','crazy','creeped out','creepy','critical','criticized',
                  'cross','crowded','cruddy','crummy','crushed','cut-down','cut-off','cynical',
                  'damaged','damned','dangerous','dark','dazed','dead','deceived','deep',
                  'defamed','defeated','defective','defenseless','defensive','defiant',
                  'deficient','deflated','degraded','dehumanized','dejected','delicate',
                  'deluded','demanding','demeaned','demented','demoralized','demotivated',
                  'dependent','depleted','depraved','depressed','deprived','deserted',
                  'deserving of pain/punishment','desolate','despair','despairing',
                  'desperate','despicable','despised','destroyed','destructive',
                  'detached','detest','detestable','detested','devalued','devastated',
                  'deviant','devoid','diagnosed','dictated to','different','difficult',
                  'directionless','dirty','disabled','disagreeable','disappointed',
                  'disappointing','disapproved of','disbelieved','discardable','discarded',
                  'disconnected','discontent','discouraged','discriminated','disdain',
                  'disdainful','disempowered','disenchanted','disgraced','disgruntled',
                  'disgust','disgusted','disheartened','dishonest','dishonorable',
                  'disillusioned','dislike','disliked','dismal','dismayed','disorganized',
                  'disoriented','disowned','displeased','disposable','disregarded',
                  'disrespected','dissatisfied','distant','distracted','distraught',
                  'distressed','disturbed','dizzy','dominated','doomed','double-crossed',
                  'doubted','doubtful','down','down and out','down in the dumps',
                  'downhearted','downtrodden','drained','dramatic','dread','dreadful',
                  'dreary','dropped','drunk','dry','dumb','dumped','dumped on','duped',
                  'edgy','egocentric','egotistic','egotistical','elusive','emancipated',
                  'emasculated','embarrassed','emotional','emotionless','emotionally bankrupt',
                  'empty','encumbered','endangered','enraged','enslaved','entangled','evaded',
                  'evasive','evicted','excessive','excluded','exhausted','exploited','exposed',
                  'fail','failful','fake','false','fear','fearful','fed up','flawed','forced',
                  'forgetful','forgettable','forgotten','fragile','freaked out','frightened',
                  'frigid','frustrated','furious','gloomy','glum','gothic','grey','grief','grim',
                  'gross','grossed-out','grotesque','grouchy','grounded','grumpy','guilt-tripped',
                  'guilty','harassed','hard','hard-hearted','harmed','hassled','hate','hateful',
                  'hatred','haunted','heartbroken','heartless','heavy-hearted','helpless',
                  'hesitant','hideous','hindered','hopeless','horrible','horrified','horror',
                  'hostile','hot-tempered','humiliated','hung up','hung over','hurried','hurt',
                  'hysterical','idiot','idiotic','ignorant','ignored','ill','ill-tempered',
                  'imbalanced','imposed-upon','impotent','imprisoned','impulsive','in the dumps',
                  'in the way','inactive','inadequate','incapable','incommunicative','incompetent',
                  'incompatible','incomplete','incorrect','indecisive','indifferent',
                  'indoctrinated','inebriated','ineffective','inefficient','inferior',
                  'infuriated','inhibited','inhumane','injured','injusticed','insane',
                  'insecure','insignificant','insincere','insufficient','insulted',
                  'intense','interrogated','interrupted','intimidated','intoxicated',
                  'invalidated','invisible','irrational','irritable','irritated',
                  'isolated','jaded','jealous','jerked around','joyless','judged',
                  'kept apart','kept away','kept in','kept out','kept quiet','labeled',
                  'laughable','laughed at','lazy','leaned on','lectured to','left out',
                  'let down','lied about','lied to','limited','little','lonely','lonesome',
                  'longing','lost','lousy','loveless','low','mad','made fun of','man handled',
                  'manipulated','masochistic','messed with','messed up','messy','miffed',
                  'miserable','misled','mistaken','mistreated','mistrusted','misunderstood',
                  'mixed-up','mocked','molested','moody','nagged','needy','negative',
                  'nervous','neurotic','nonconforming','numb','nuts','nutty','objectified',
                  'obligated','obsessed','obsessive','obstructed','odd','offended',
                  'on display','opposed','oppressed','out of place','out of touch',
                  'over-controlled','over-protected','overwhelmed','pain','panic','paranoid',
                  'passive','pathetic','pessimistic','petrified','phony','picked on','pissed',
                  'pissed off','plain','played with','pooped','poor','powerless','pre-judged',
                  'preached to','preoccupied','predjudiced','pressured','prosecuted',
                  'provoked','psychopathic','psychotic','pulled apart','pulled back',
                  'punished','pushed','pushed away','put down','puzzled','quarrelsome',
                  'queer','questioned','quiet','rage','raped','rattled','regret','rejected',
                  'resented','resentful','responsible','retarded','revengeful','ridiculed',
                  'ridiculous','robbed','rotten','sad','sadistic','sarcastic','scared',
                  'scarred','screwed','screwed over','screwed up','self-centered','self-conscious',
                  'self-destructive','self-hatred','selfish','sensitive','shouted at','shy',
                  'singled-out','slow','small','smothered','snapped at','spiteful','stereotyped',
                  'strange','stressed','stretched','stuck','stupid','submissive','suffering',
                  'suffocated','suicidal','superficial','suppressed','suspicious','worse','worst'
                  ,'bankrupcy','jobs','shit','socialism','#sob']
                  
stopwords = nltk.corpus.stopwords.words('english')
ignore_list = ['',' ','-','rt']

def lexical_diversity(text):
    return len(text) / len(set(text))
    
def percentage(count, total):
    return 100 * count / total

def analise_sentimento(texto, listabom, listamal):
    #Ler http://alias-i.com/lingpipe/demos/tutorial/sentiment/read-me.html
    indice_bom = 0
    indice_ruim = 0    
    for word in listabom:
        indice_bom += percentage(texto.count(word.lower()), len(texto))
    for word in listamal:
        indice_ruim += percentage(texto.count(word.lower()), len(texto))
    print 'Grau de negatividade = %s ' %indice_ruim
    print 'Grau de positividade = %s ' %indice_bom
    return indice_bom, indice_ruim

def comandos_para_testar_analise_palavras(tweets_words, names):
    print 'Quantidade de palavras: ', len(tweets_words)
    print 'Quantidade de palavras unicas: ', len(set(tweets_words))
    print 'Diversidade lexical: ', lexical_diversity(tweets_words)
    freq_dist = nltk.FreqDist(tweets_words)
    freq_dist.plot()
    freq_dist.plot(40)
    freq_dist.plot(40, cumulative = True)    
    print '10 palavras mais frequentes'
    print freq_dist.keys()[:10]
    print '10 palavras menos frequentes'
    print freq_dist.keys()[-10:]
    print 'Lista de palavras ordenada', sorted(set(tweets_words))
    #retira as stopwords. Podem-se retirar outras palavras acrescentando-as aa lista 'ignore_list'    
    new_tweets_words = [word for word in tweets_words if word not in (stopwords or ignore_list)]
    freq_new = nltk.FreqDist(new_tweets_words)    
    freq_new.plot()
    freq_new.plot(40)
    freq_new.plot(40, cumulative = True)        
    #contagem de palavras especificas    
    new_tweets_words.count('bad')
    new_tweets_words.count('good')
    freq_new['good'] #equivalente aa de cima
    freq_new.freq('good') #frequencia relativa de uma palavra
    #retiram-se as palavras pequenas
    bigger_tweets_words = [word for word in new_tweets_words if len(word) > 2]
    #escolhem-se palavras em uma faixa de tamanhos    
    mediumsized_tweets_words = [word for word in new_tweets_words if len(word) > 2 and len(word) < 9]
    #Analise de citacoes
    citacoes = [word for word in tweets_words if word.startswith('@')]
    freq_citacoes = nltk.FreqDist(citacoes)
    freq_citacoes.itens()
    freq_citacoes.plot()
    #Analise de Hashtags
    hashtags = [word for word in tweets_words if word.startswith('#')]
    freq_hashtags = nltk.FreqDist(hashtags)
    freq_hashtags.itens()
    freq_hashtags.plot()
    #Analise de palavras frequentes. Pode-se trocar tweets_words por quaisquer das listas derivadas acima
    frequent_words = [word.lower() for word in new_tweets_words if tweets_words.count(word) > 5]
    freq_dist2 = nltk.FreqDist(frequent_words)
    freq_dist2.plot()
    #tamanhos das palavras
    freqtamwords = nltk.FreqDist([len(w) for w in new_tweets_words])
    freqtamwords.items()
    freqtamwords.plot()
    #Bigramas
    bigramas_tweets = nltk.bigrams(new_tweets_words)
    freqbig = nltk.FreqDist(bigramas_tweets)
    freqbig.plot(20)
    #Nomes (palavras capitalizadas)
    freq_names = nltk.FreqDist(names)
    freq_names.plot(20)
    
"""Programa Principal"""
api = twitter.Api() # Acesso sem autenticacao

# Para conseguir acesso autenticado:
# Ler https://dev.twitter.com/docs/auth/oauth
# Registrar a aplicacao em https://dev.twitter.com/apps/new

#api = twitter.Api(consumer_key = ck, consumer_secret = cs, 
#                  access_token_key = atk, access_token_secret = ats)

#tweets, tweets_txt, tweets_words, names = buscaportermo('Obama')          
#testar cada uma das linhas da funcao "comandos_para_testar_analise_palavras(tweets_words):"
#analise_sentimento(tweets_words, lista_positiva, lista_negativa)
#testar cada um dos comandos da funcao 'comandos_para_criacao_dos_grafos(tweets):'




# Mais recentes mensagens publicas
#msgpublicas = api.GetPublicTimeline() 
#print [s.user.name for s in msgpublicas]

# Mais recentes mensagens de um usuario
#msguser = api.GetUserTimeline('rrsouza')
#print [s.text for s in msguser]

#Depois de autenticar...
#userfollow = api.GetFriends() # consultar os "seguidos" 
#print [u.name for u in userfollow]

#userfollowers = api.GetFollowers() #consultar os seguidores
#print [u.name for u in userfollowers]

#userfriendstimeline = api.GetFriendsTimeline()
#print [u.text for u in userfriendstimeline]

# Uma busca por um termo em tweets
#search = api.GetSearch('Petrobras')
#print [s.text for s in search]

# Para saber mais do que se pode fazer, digite no prompt: pydoc twitter.Api