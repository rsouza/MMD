# -*- coding: utf-8 -*-
import os
import sys
import webbrowser
import urllib
from urllib import urlencode
import urllib2
import json
import nltk
import facebook #https://github.com/facebook/python-sdk
import webbrowser
import shutil
import operator
from copy import deepcopy
from cgi import escape

# Codigo adaptado de facebook__login.py, facebook__graph_query.py, facebook__fql_query.py,
# facebook__get_friends_rgraph.py,facebook__sunburst.py, facebook__popularity_spreadsheet.py
# facebook__filter_rgraph_output_by_group.py, facebook__tag_cloud.py

#Ver implementacao de algumas funcionalidades no GAE - http://miningthesocialweb.appspot.com/

# Gerar estes valores criando uma aplicacao para o Facebook em:
# http://www.facebook.com/developers
AppID = 'preencher o seu'
AppSecret = 'preencher o seu'
ACCESS_TOKEN = 'preencher o seu ou gerar pela funcao login'
SiteURL = 'http://miningthesocialweb.appspot.com/static/facebook_oauth_helper.html'
LIMIT = 10

datapath = "/home/rsouza/Dropbox/Renato/Python/MMD/"
datapath2 = "/home/rsouza/Dropbox/Renato/Python/MMD/out/jit/rgraph/"
datapath3 = "/home/rsouza/Dropbox/Renato/Python/MMD/out/jit/sunburst/"
datapath4 = "/home/rsouza/Dropbox/Renato/Python/MMD/out/wp_cumulus/"

htmlfile1 = 'rgraph.html'
htmlfile2 = 'sunburst.html'
htmlfile3 = 'tagcloud_template.html'
rgraphtemplate = (datapath2+htmlfile1)
sunbursttemplate = (datapath3+htmlfile2)
tagcloudtemplate = (datapath4+htmlfile3)

graphhtml = 'fb_amigos.html'
graphhtmlgroup = 'fb_amigos_group.html'
graphjson = 'fb_amigos.json'
graphsun = 'fb_amigos_sun.html'
graphcloud = 'fb_tag_cloud.html'
csvfile = 'fb_amigos.csv'
rgraphfile = (datapath+graphhtml)
rgraphfile2 = (datapath+graphhtmlgroup)
dumpjson = (datapath+graphjson)
sungraphfile = (datapath+graphsun)
graphcloudfile = (datapath+graphcloud)
planilha = (datapath+csvfile)

# Tambem se pode realizar esta processo de login manualmente
# Autorizar a aplicacao em: http://developers.facebook.com/docs/authentication/

def login():
    CLIENT_ID = AppID
    REDIRECT_URI = SiteURL
    # Pode-se customizar as permissoes pretendidas para o login facebook default.
    # Todos aqueles que sao incluidos por default para acesso de leitura estao
    # incluidos em http://developers.facebook.com/docs/authentication/ 
    # Para uma aplicacao tipica, nao seria adequado pedir tantas permissoes
    EXTENDED_PERMS = ['user_about_me','friends_about_me','user_activities',
        'friends_activities','user_birthday','friends_birthday','user_education_history',
        'friends_education_history','user_events','friends_events','user_groups',
        'friends_groups','user_hometown','friends_hometown','user_interests',
        'friends_interests','user_likes','friends_likes','user_location',
        'friends_location','user_notes','friends_notes','user_online_presence',
        'friends_online_presence','user_photo_video_tags','friends_photo_video_tags',
        'user_photos','friends_photos','user_relationships','friends_relationships',
        'user_religion_politics','friends_religion_politics','user_status',
        'friends_status','user_videos','friends_videos','user_website',
        'friends_website','user_work_history','friends_work_history','email',
        'read_friendlists','read_requests','read_stream','user_checkins',
        'friends_checkins']

    args = dict(client_id=CLIENT_ID, redirect_uri=REDIRECT_URI,
                scope=','.join(EXTENDED_PERMS), type='user_agent', display='popup')
                
    #webbrowser.open('https://graph.facebook.com/oauth/authorize?'+ urllib.urlencode(args))
    webbrowser.open('https://www.facebook.com/dialog/oauth?'+ urllib.urlencode(args))
    access_token = raw_input('Enter your access_token: ')
    if not os.path.isdir('out'): os.mkdir('out')
    filename = os.path.join('out', 'facebook.access_token')
    f = open(filename, 'w')
    f.write(access_token)
    f.close()
    print >> sys.stderr, "Access token gravado em: 'out/facebook.access_token'"
    return access_token

def find_groups(query):
    # Query ao Facebook GRAPH API 
    # http://developers.facebook.com/tools/explorer/
    # Busca grupos a partir de um termo - 'query' para consulta, limitado por LIMIT
    group_ids = []
    i = 0
    while True:
        results = gapi.request('search', {'q': query,'type': 'group','limit': LIMIT,
                               'offset': LIMIT * i,})
        if not results['data']: break
        ids = [group['id'] for group in results['data'] if group['name'
               ].lower().find('programming') > -1]
        # once groups stop containing the term we are looking for in their name, bail out
        if len(ids) == 0: break
        group_ids += ids
        i += 1
    if not group_ids:
        print 'No results'
        sys.exit()
    # Recupera os detalhes dos grupos
    groups = gapi.get_objects(group_ids, metadata=1)
    # Conta o numero de membros em cada grupo. Consultar:
    # http://developers.facebook.com/docs/reference/fql/group_member
    for g in groups:
        group = groups[g]
        conn = urllib2.urlopen(group['metadata']['connections']['members'])
        try: members = json.loads(conn.read())['data']
        finally: conn.close()
        print group['name'], len(members)
        

class FQL(object):
    #Classe para queries complexas usando FQL
    #http://developers.facebook.com/docs/reference/fql/
    # Uma alternativa mais poderosa ao GRAPH API
    ENDPOINT = 'https://api.facebook.com/method/'

    def __init__(self, access_token=None):
        self.access_token = access_token

    def _fetch(cls, url, params=None):
        conn = urllib2.urlopen(url, data=urlencode(params))
        try:
            return json.loads(conn.read())
        finally:
            conn.close()

    def query(self, q):
        if q.strip().startswith('{'):
            return self.multiquery(q)
        else:
            params = dict(query=q, access_token=self.access_token, format='json')
            url = self.ENDPOINT + 'fql.query'
            return self._fetch(url, params=params)

    def multiquery(self, q):
        params = dict(queries=q, access_token=self.access_token, format='json')
        url = self.ENDPOINT + 'fql.multiquery'
        return self._fetch(url, params=params)


def fql_queries(fqlquery):
    fql = FQL(access_token=ACCESS_TOKEN)
    result = fql.query(fqlquery)
    print json.dumps(result, indent=4)
    return result

def graph_friends():
    fql = FQL(access_token=ACCESS_TOKEN)
    q = "select target_id from connection where source_id = me() and target_type ='user'"
    my_friends = [str(t['target_id']) for t in fql.query(q)]
    # Para conseguir a lista de amizades mutuas entre seus amigos, ha que se passar
    # um numero limitado de requisicoes por vez, e por isso esta consulta e dividida
    # e depois os resultados sao agregados. Dependendo do numero de amigos, podem
    # ser realizadas varias chamadas aa API e muitos dados recuperados    
    mutual_friendships = []
    N = 50
    for i in range(len(my_friends) / N + 1):
        q = 'select uid1, uid2 from friend where uid1 in (%s) and uid2 in (%s)' \
        %(','.join(my_friends), ','.join(my_friends[i * N:(i + 1) * N]))
        mutual_friendships += fql.query(q)
    # Recupera detalhes sobre seus amigos e cria um mapa. Nem todas as informacoes
    # serao fornecidas     
    q = 'select uid, first_name, last_name, sex from user where uid in (%s)' \
    % (','.join(my_friends), )
    results = fql.query(q)
    names = dict([(unicode(u['uid']), u['first_name'] + ' ' + u['last_name'][0] + '.'
             ) for u in results])
    sexes = dict([(unicode(u['uid']), u['sex']) for u in results])
    # consolida um mapa de conexoes entre os amigos
    friendships = {}
    for f in mutual_friendships:
        (uid1, uid2) = (unicode(f['uid1']), unicode(f['uid2']))
        try: name1 = names[uid1]
        except KeyError, e:
            name1 = 'Unknown'
        try: name2 = names[uid2]
        except KeyError, e:
            name2 = 'Unknown'
        if friendships.has_key(uid1):
            if uid2 not in friendships[uid1]['friends']:
                friendships[uid1]['friends'].append(uid2)
        else:
            friendships[uid1] = {'name': name1, 'sex': sexes.get(uid1, ''),
                                 'friends': [uid2]}
        if friendships.has_key(uid2):
            if uid1 not in friendships[uid2]['friends']:
                friendships[uid2]['friends'].append(uid1)
        else:
            friendships[uid2] = {'name': name2, 'sex': sexes.get(uid2, ''),
                                 'friends': [uid1]}
    return friendships, names, sexes, mutual_friendships
    
def gera_rgraph_friends(friendships,names):    
    # Gera o arquivo JIT para visualizacao no navegador
    jit_output = []
    for fid in friendships:
        friendship = friendships[fid]
        adjacencies = friendship['friends']
        connections = '<br>'.join([names.get(a, 'Unknown') for a in adjacencies])
        normalized_popularity = 1.0 * len(adjacencies) / len(friendships)
        sex = friendship['sex']
        jit_output.append({
            'id': fid,
            'name': friendship['name'],
            'data': {'connections': connections, 'normalized_popularity'
                     : normalized_popularity, 'sex': sex},
                     'adjacencies': adjacencies,
                     })
    # Grava o resultado em arquivo fb_amigos.html a partir do template rgraph.html
    html = open(rgraphtemplate).read() %(json.dumps(jit_output),)
    f = open(rgraphfile, 'w')
    f.write(html)
    f.close()
    print >> sys.stderr, 'Dados gravados no arquivo: %s' %f.name
    # Grava o resultado tambem em um arquivo JSON para analises adicionais
    json_f = open(dumpjson, 'w')
    json_f.write(json.dumps(jit_output, indent=4))
    json_f.close()
    print 'Dados gravados no arquivo: %s' % json_f.name
    # Abre a pagina no navegador padrao
    #webbrowser.open('file://' + f.name)

def gera_rgraph_friends_bygroup():
    # Reusa o arquivo json salvo anteriormente
    rgraph = json.loads(open(dumpjson).read())
    groups = gapi.get_connections('me', 'groups')
    # Display groups and prompt the user
    for i in range(len(groups['data'])):
        print '%s) %s' %(i, groups['data'][i]['name'])
    choice = int(raw_input('Escolha um dos grupos para o grafico: '))
    gid = groups['data'][choice]['id']
    # Find the friends in the group
    fql = FQL(ACCESS_TOKEN)
    q = """select uid from group_member where gid = %s and uid in (select target_id\
    from connection where source_id = me() and target_type = 'user')"""%(gid, )
    uids = [u['uid'] for u in fql.query(q)]
    # Filter the previously generated output for these ids
    filtered_rgraph = [n for n in rgraph if n['id'] in uids]
    # Trim down adjancency lists for anyone not appearing in the graph.
    # Note that the full connection data displayed as HTML markup
    # in "connections" is still preserved for the global graph.
    for n in filtered_rgraph:
        n['adjacencies'] = [a for a in n['adjacencies'] if a in uids]
    html = open(rgraphtemplate).read() %(json.dumps(filtered_rgraph),)
    f = open(rgraphfile2, 'w')
    f.write(html)
    f.close()
    print 'Dados gravados no arquivo: %s' %f.name
    # Abre a pagina no navegador padrao
    #webbrowser.open('file://' + f.name)
    
def gera_sungraph_friends():
    # Reusa o arquivo json salvo anteriormente
    data = json.loads(open(dumpjson).read())
    # Define as cores a serem usadas na visualizacao
    colors = ['#FF0000', '#00FF00', '#0000FF']
    # O output primario para coletar os inputs
    jit_output = {'id': 'friends','name': 'friends','data': {'$type': 'none'},
                  'children': [],}
    # Um template para a visualizacao
    template = {'id': 'friends','name': 'friends','data': {'connections': '',\
                '$angularWidth': 1, '$color': ''},'children': [],}
    i = 0
    for g in ['male', 'female']:
        # Cria o objeto "genero"
        go = deepcopy(template)
        go['id'] += '/' + g
        go['name'] += '/' + g
        go['data']['$color'] = colors[i]
        # Busca os amigos por genero
        friends_by_gender = [f for f in data if f['data']['sex'] == g]
        for f in friends_by_gender:
            # Carrega os amigos no objeto "genero"
            fo = deepcopy(template)
            fo['id'] = f['id']
            fo['name'] = f['name']
            fo['data']['$color'] = colors[i % 3]
            fo['data']['$angularWidth'] = len(f['adjacencies'])  # Ranqueia por popularidade
            fo['data']['connections'] = f['data']['connections']
            go['children'].append(fo)
        jit_output['children'].append(go)
        i += 1
    # gera o output esperado pelo JIT Sunburst
    html = open(sunbursttemplate).read() %(json.dumps(jit_output),)
    f = open(sungraphfile, 'w')
    f.write(html)
    f.close()
    print 'Dados gravados no arquivo: %s' %f.name
    # Abre a pagina no navegador padrao
    #webbrowser.open('file://' + f.name)

def weightTermByFreq(f, minfr,maxfr,minfo,maxfo):
    return (f - minfr) * (maxfo - minfo) / (maxfr - minfr) + minfo

def gera_tag_cloud():
    #try:
    #    ACCESS_TOKEN = open('out/facebook.access_token').read()
    #except IOError, e:
    #    try:
    #        ACCESS_TOKEN = sys.argv[1]
    #    except IndexError, e:
    #        print >> sys.stderr, \
    #            "Could not either find access token in 'facebook.access_token' or parse args. Logging in..."
    #        ACCESS_TOKEN = login()
    BASE_URL = 'https://graph.facebook.com/me/home?access_token='
    NUM_PAGES = 5
    MIN_FREQUENCY = 1
    MIN_FONT_SIZE = 3
    MAX_FONT_SIZE = 20
    # Loop through the pages of connection data and build up messages
    url = BASE_URL + ACCESS_TOKEN
    messages = []
    current_page = 0
    while current_page < NUM_PAGES:
        data = json.loads(urllib2.urlopen(url).read())
        messages += [d['message'] for d in data['data'] if d.get('message')]
        current_page += 1
        url = data['paging']['next']
    # Compute frequency distribution for the terms
    fdist = nltk.FreqDist([term for m in messages for term in m.split()])
    # Customize a list of stop words as needed
    stop_words = nltk.corpus.stopwords.words('english')
    stop_words += nltk.corpus.stopwords.words('portuguese')
    stop_words += ['&', '.', '?', '!','...']
    # Create output for the WP-Cumulus tag cloud and sort terms by freq along the way
    raw_output = sorted([[escape(term), '', freq] for (term, freq) in fdist.items()
                        if freq > MIN_FREQUENCY and term not in stop_words],
                        key=lambda x: x[2])
    # Implementation adapted from http://help.com/post/383276-anyone-knows-the-formula-for-font-s
    min_freq = raw_output[0][2]
    max_freq = raw_output[-1][2]
    weighted_output = [[i[0], i[1], weightTermByFreq(i[2], min_freq,max_freq,\
                        MIN_FONT_SIZE,MAX_FONT_SIZE)] for i in raw_output]
    # Substitute the JSON data structure into the template
    html_page = open(tagcloudtemplate).read() % (json.dumps(weighted_output), )
    f = open(graphcloudfile, 'w')
    f.write(html_page)
    f.close()
    print 'Dados gravados no arquivo: %s' %f.name
    # Open up the web page in your browser
    # webbrowser.open('file://' + os.path.join(os.getcwd(), graphcloudfile))

def gera_planilha_friends():    
    # Reusa o arquivo json salvo anteriormente
    data = json.loads(open(dumpjson).read())
    popularity_data = [(f['name'], len(f['adjacencies'])) for f in data]
    popularity_data = sorted(popularity_data, key=operator.itemgetter(1))
    csv_data = []
    for d in popularity_data: csv_data.append('%s\t%s' % (d[0], d[1]))
    f = open(planilha, 'w')
    f.write('\n'.join(csv_data))
    f.close()
    print 'Dados gravados no arquivo: %s' %f.name

        
if __name__ == '__main__':
    #ACCESS_TOKEN = login()
    #gapi = facebook.GraphAPI(ACCESS_TOKEN)
    #Query com Graph API (http://developers.facebook.com/tools/explorer/)
    #find_groups('FGV')

    #Queries com FQL (http://developers.facebook.com/docs/reference/fql/)
    fqlquery0 = "select name, sex, relationship_status from user WHERE uid = me()"    
    fqlquery1 = "select first_name, last_name, birthday from user WHERE uid IN \
    (select uid1 FROM friend WHERE uid2 = me())"  
    fqlquery2 = "select name, sex, relationship_status from user where uid in \
    (select target_id from connection where source_id = me() and target_type = 'user')"
    #Exemplo de multiquery FQL    
    fqlquery3 = """{"name_sex_relationships" : "select name, sex, relationship_status from user \
    where uid in (select target_id from #ids)","ids" : "select target_id from connection \
    where source_id = me() and target_type = 'user'"}"""
    fqlquery4 = "select target_id from connection where source_id = me() and target_type = 'user'"

    #results = fql_queries(fqlquery4) #troque o numero da query e experimente a FQL


    #my_friends_names = [str(t['first_name']+' '+str(t['last_name'])) for t in fql_queries(fqlquery1)]
    #my_friends_names = set(my_friends_names) #ordenar

    #my_friends_ids = [str(t['target_id']) for t in fql_queries(fqlquery4)]
    #fqlquery5 = "select uid1, uid2 from friend where uid1 in (%s) and uid2 in (%s)" \
    #%(",".join(my_friends_ids), ",".join(my_friends_ids),)
    #mutual_friendships = fql_queries(fqlquery5)
    
    #fqlquery6 = "select uid, first_name, last_name, sex from user where uid in (%s)" \
    #%(",".join(my_friends_ids),)
    #names = dict([(unicode(u["uid"]), u["first_name"] + " " +u["last_name"][0] + ".") for u in fql_queries(fqlquery6)])
    
    
    #friendships, names, sexes, mutual_friendships = graph_friends()
    #gera_rgraph_friends(friendships,names)
    #gera_sungraph_friends()
    #gera_rgraph_friends_bygroup()
    gera_tag_cloud()
    #gera_planilha_friends()